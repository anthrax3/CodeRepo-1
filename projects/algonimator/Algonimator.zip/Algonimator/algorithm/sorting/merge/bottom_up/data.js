var tracer = new Array2DTracer();
var logger = new LogTracer();
var D = [
    Array1D.random(20, 0, 50),
    Array1D.random(20, 0, 0)
];

tracer._setData(D);