var tracer = new Array1DTracer('Euclidean Algorithm');
var a = [];
a.push(465);
a.push(255)
tracer._setData(a);
var logger = new LogTracer();
