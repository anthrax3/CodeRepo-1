var tracer = new Array1DTracer();
var logger = new LogTracer();
var D = [-2, -3, 4, -1, -2, 1, 5, -3];
tracer._setData(D);