var tracer = new Array1DTracer('Sequence');
var index = 15;
var D = [1, 1];
for (var i = 2; i < index; i++) {
    D.push(0);
}
tracer._setData(D);
